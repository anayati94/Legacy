<?php
$xmlstr = <<<XML
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE extension SYSTEM "ext-1.0.dtd">

<!--

/*
 * Copyright (C) 2014-2016 Studio 384
 * Licensed under MIT
 */
-->

<style engine="1.0">
	<id>fifteen</id>
	<name>Fifteen</name>
	<developer>Studio 384</developer>
	<date>4 June 2016</date>
	<version>2.0.3</version>
	<minversion>2.0.0</minversion>
	<maxversion>2.0.3</maxversion>
</style>
XML;
?>
