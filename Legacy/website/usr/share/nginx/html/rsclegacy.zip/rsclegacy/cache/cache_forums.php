<?php

define('LUNA_LIST_LOADED', 1);

$luna_forums = array (
  0 => 
  array (
    'id' => '1',
    'forum_name' => 'News',
    'color' => '#2788cb',
    'icon' => '',
  ),
  1 => 
  array (
    'id' => '2',
    'forum_name' => 'General Discussion',
    'color' => '#2788cb',
    'icon' => '',
  ),
  2 => 
  array (
    'id' => '5',
    'forum_name' => 'Equipment',
    'color' => '#2788cb',
    'icon' => '',
  ),
  3 => 
  array (
    'id' => '6',
    'forum_name' => 'Supplies',
    'color' => '#2788cb',
    'icon' => '',
  ),
  4 => 
  array (
    'id' => '7',
    'forum_name' => 'Services',
    'color' => '#2788cb',
    'icon' => '',
  ),
  5 => 
  array (
    'id' => '8',
    'forum_name' => 'Support',
    'color' => '#2788cb',
    'icon' => '',
  ),
  6 => 
  array (
    'id' => '9',
    'forum_name' => 'Off Topic Discussion',
    'color' => '#2788cb',
    'icon' => '',
  ),
  7 => 
  array (
    'id' => '10',
    'forum_name' => 'Community Media',
    'color' => '#2788cb',
    'icon' => '',
  ),
  8 => 
  array (
    'id' => '12',
    'forum_name' => 'Introductions',
    'color' => '#2788cb',
    'icon' => '',
  ),
  9 => 
  array (
    'id' => '13',
    'forum_name' => 'Feedback',
    'color' => '#2788cb',
    'icon' => '',
  ),
  10 => 
  array (
    'id' => '14',
    'forum_name' => 'Change Log',
    'color' => '#2788cb',
    'icon' => '',
  ),
  11 => 
  array (
    'id' => '15',
    'forum_name' => 'Suggestions',
    'color' => '#2788cb',
    'icon' => '',
  ),
  12 => 
  array (
    'id' => '16',
    'forum_name' => 'Staff Discussion',
    'color' => '#2788cb',
    'icon' => '',
  ),
  13 => 
  array (
    'id' => '17',
    'forum_name' => 'Bugs Report',
    'color' => '#2788cb',
    'icon' => '',
  ),
  14 => 
  array (
    'id' => '18',
    'forum_name' => 'Evidence Room',
    'color' => '#2788cb',
    'icon' => '',
  ),
  15 => 
  array (
    'id' => '19',
    'forum_name' => 'Staff Application',
    'color' => '#2788cb',
    'icon' => '',
  ),
  16 => 
  array (
    'id' => '20',
    'forum_name' => 'PC Bugs Report',
    'color' => '#2788cb',
    'icon' => '',
  ),
  17 => 
  array (
    'id' => '21',
    'forum_name' => 'Android Bugs Report',
    'color' => '#2788cb',
    'icon' => '',
  ),
  18 => 
  array (
    'id' => '23',
    'forum_name' => 'Ban Appeal',
    'color' => '#2788cb',
    'icon' => '',
  ),
  19 => 
  array (
    'id' => '25',
    'forum_name' => 'Clans',
    'color' => '#2788cb',
    'icon' => '',
  ),
  20 => 
  array (
    'id' => '26',
    'forum_name' => 'Clan Media',
    'color' => '#2788cb',
    'icon' => '',
  ),
  21 => 
  array (
    'id' => '27',
    'forum_name' => 'Staff Archive',
    'color' => '#2788cb',
    'icon' => '',
  ),
  22 => 
  array (
    'id' => '28',
    'forum_name' => 'Website Bugs Report',
    'color' => '#2788cb',
    'icon' => '',
  ),
  23 => 
  array (
    'id' => '29',
    'forum_name' => 'Events',
    'color' => '#2788cb',
    'icon' => '',
  ),
  24 => 
  array (
    'id' => '30',
    'forum_name' => 'Bugs Report',
    'color' => '#2788cb',
    'icon' => '',
  ),
  25 => 
  array (
    'id' => '31',
    'forum_name' => 'Graveyard',
    'color' => '#2788cb',
    'icon' => 'lock',
  ),
);

?>