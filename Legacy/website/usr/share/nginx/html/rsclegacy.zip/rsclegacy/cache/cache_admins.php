<?php

define('LUNA_ADMINS_LOADED', 1);

$luna_admins = array (
  0 => '2',
  1 => '3',
  2 => '31',
);

?>