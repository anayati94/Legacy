<?php

$db_type = 'mysqli';
$db_host = 'localhost';
$db_name = 'rsclegacy';
$db_username = 'rsclegacy';
$db_password = 'wildy456';
$db_prefix = '';
$p_connect = false;

$cookie_name = 'luna_cookie_4e2448';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'd8f57f0faa47aa13';

define('PUN', 1);
//define('LUNA_DEBUG', 1);
//define('LUNA_SHOW_QUERIES', 1);