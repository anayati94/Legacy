<?php

/*
 * Copyright (C) 2016 RSCL @author Imposter
 * Shop Container.
 */

class ShopContainer {
	var $id;
	var $item_id;
	var $name;
	var $image;
	var $price;
	var $quantity;
}
?>