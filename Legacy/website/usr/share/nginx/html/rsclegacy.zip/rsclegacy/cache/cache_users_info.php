<?php

define('LUNA_USERS_INFO_LOADED', 1);

$stats = array (
  'total_users' => '10093',
  'last_user' => 
  array (
    'id' => '12314',
    'username' => 'Nervousnate',
  ),
);

?>