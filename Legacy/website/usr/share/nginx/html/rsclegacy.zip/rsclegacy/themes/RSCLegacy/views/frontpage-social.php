<?php

// Make sure no one attempts to run this view directly.
if (!defined('FORUM'))
	exit;
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div id="social">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title">FACEBOOK - LIKE US!</h4>
		</div>
		<div class="base_body in">
			<div class="fb-page" data-href="https://www.facebook.com/RSCLegacy" data-tabs="timeline" data-width="241" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/RSCLegacy" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/RSCLegacy">RSCLegacy</a></blockquote></div>
		</div>
	</div>
</div>