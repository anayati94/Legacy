<?php
$settings['sellerEmail'] = "service@rsclegacy.com";	// PayPal email
$settings['sandbox'] = false;

$donationOffers =
array( 
	array(
	Jewel => 100,
	Price => 1.34,
	Stone => 2
	), 
	array(
	Jewel => 540,
	Price => 5.46,
	Stone => 5
	), 
	array(
	Jewel => 1080,
	Price => 10.61,
	Stone => 10
	), 
	array(
	Jewel => 1700,
	Price => 15.76,
	Stone => 15
	), 
	array(
	Jewel => 2400,
	Price => 20.91,
	Stone => 25
	), 
	array(
	Jewel => 6600,
	Price => 51.80,
	Stone => 35
	), 
	array(
	Jewel => 14700,
	Price => 103.30,
	Stone => 75
	), 
);
?>