<?php

define('LUNA_RANKS_LOADED', 1);

$luna_ranks = array (
  0 => 
  array (
    'id' => '1',
    'rank' => 'New member',
    'min_comments' => '0',
  ),
  1 => 
  array (
    'id' => '2',
    'rank' => 'Member',
    'min_comments' => '10',
  ),
);

?>