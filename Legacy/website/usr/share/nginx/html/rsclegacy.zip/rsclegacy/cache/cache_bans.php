<?php

define('LUNA_BANS_LOADED', 1);

$luna_bans = array (
  0 => 
  array (
    'id' => '4',
    'username' => NULL,
    'ip' => '101.186.125.194',
    'email' => NULL,
    'message' => 'Unauthorized account access - You\'re not allowed here.',
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  1 => 
  array (
    'id' => '3',
    'username' => NULL,
    'ip' => '173.17.195.86',
    'email' => NULL,
    'message' => 'You\'re not allowed here under any circumstances.',
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  2 => 
  array (
    'id' => '5',
    'username' => 'badoman',
    'ip' => NULL,
    'email' => NULL,
    'message' => 'Unauthorized account access - You\'re not allowed here.',
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  3 => 
  array (
    'id' => '6',
    'username' => 'rudy5',
    'ip' => '104.131.159.189',
    'email' => 'rudy5@email.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  4 => 
  array (
    'id' => '7',
    'username' => 'rudy',
    'ip' => '104.131.159.189',
    'email' => 'rudy@email.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  5 => 
  array (
    'id' => '8',
    'username' => 'rudy8',
    'ip' => '194.187.251.163',
    'email' => 'axqdzdbn@sharklasers.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  6 => 
  array (
    'id' => '9',
    'username' => NULL,
    'ip' => '71.168.97.137',
    'email' => NULL,
    'message' => 'You\'re not allowed here under any circumstances.',
    'expire' => NULL,
    'ban_creator' => '31',
  ),
  7 => 
  array (
    'id' => '10',
    'username' => NULL,
    'ip' => '76.25.2.171',
    'email' => NULL,
    'message' => 'Botting is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  8 => 
  array (
    'id' => '11',
    'username' => NULL,
    'ip' => '184.100.30.246',
    'email' => NULL,
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  9 => 
  array (
    'id' => '12',
    'username' => 'Mod Bat',
    'ip' => NULL,
    'email' => 'modbatrsclegacy@gmail.com',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  10 => 
  array (
    'id' => '13',
    'username' => 'Mod Ghost',
    'ip' => NULL,
    'email' => 'dunderc63@hotmail.com',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  11 => 
  array (
    'id' => '14',
    'username' => 'Mod Hovis',
    'ip' => NULL,
    'email' => 'Modhovis@gmail.com',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  12 => 
  array (
    'id' => '15',
    'username' => 'Mod Jacob',
    'ip' => NULL,
    'email' => 'kutuliwuwu@vpn33.top',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  13 => 
  array (
    'id' => '16',
    'username' => 'Mod Kyle',
    'ip' => NULL,
    'email' => 'mod.kyle1@gmail.com',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  14 => 
  array (
    'id' => '17',
    'username' => 'Mod Matt',
    'ip' => NULL,
    'email' => 'the.road.im.on@gmail.com',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  15 => 
  array (
    'id' => '18',
    'username' => 'Mod Wealth',
    'ip' => NULL,
    'email' => NULL,
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  16 => 
  array (
    'id' => '19',
    'username' => 'nigger sr',
    'ip' => '101.98.202.192',
    'email' => 'asdasd@as324s.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '6886',
  ),
  17 => 
  array (
    'id' => '20',
    'username' => 'nigger jr',
    'ip' => '101.98.202.192',
    'email' => 'asdasd@as14.com',
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '6886',
  ),
  18 => 
  array (
    'id' => '23',
    'username' => NULL,
    'ip' => '103.10.52.83',
    'email' => NULL,
    'message' => 'Botting is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  19 => 
  array (
    'id' => '22',
    'username' => NULL,
    'ip' => '101.98.202.192',
    'email' => NULL,
    'message' => 'You are not welcome here',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  20 => 
  array (
    'id' => '24',
    'username' => NULL,
    'ip' => '91.75.162.176',
    'email' => NULL,
    'message' => 'Botting is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  21 => 
  array (
    'id' => '25',
    'username' => 'Mod Baldr',
    'ip' => NULL,
    'email' => NULL,
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  22 => 
  array (
    'id' => '26',
    'username' => 'Mod Sol',
    'ip' => NULL,
    'email' => 'oreon13162@gmail.com',
    'message' => 'No longer a Moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  23 => 
  array (
    'id' => '27',
    'username' => 'Mod Clive',
    'ip' => NULL,
    'email' => 'vuihsiung@yahoo.com.sg',
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  24 => 
  array (
    'id' => '33',
    'username' => NULL,
    'ip' => '46.19.86.1 46.19.86.2 46.19.86.3 46.19.86.4 46.19.86.5 46.19.86.6 46.19.86.7 46.19.86.8 46.19.86.9 46.19.86.10 46.19.86.11 46.19.86.12 46.19.86.13 46.19.86.14 46.19.86.15 46.19.86.16 46.19.86.17 46.19.86.18 46.19.86.19 46.19.86.20 46.19.86.21 46.19.86.22',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  25 => 
  array (
    'id' => '29',
    'username' => 'Mod Est',
    'ip' => NULL,
    'email' => NULL,
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  26 => 
  array (
    'id' => '30',
    'username' => 'Mod Boa',
    'ip' => NULL,
    'email' => NULL,
    'message' => 'No longer a moderator - not an IP ban.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  27 => 
  array (
    'id' => '38',
    'username' => NULL,
    'ip' => '46.19.86.44 46.19.86.45 46.19.86.46 46.19.86.47 46.19.86.48 46.19.86.49 46.19.86.50 46.19.86.51 46.19.86.52 46.19.86.53 46.19.86.54 46.19.86.55 46.19.86.56 46.19.86.57 46.19.86.58 46.19.86.59 46.19.86.60 46.19.86.61',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  28 => 
  array (
    'id' => '37',
    'username' => NULL,
    'ip' => '46.19.86.23 46.19.86.24 46.19.86.25 46.19.86.26 46.19.86.27 46.19.86.28 46.19.86.29 46.19.86.30 46.19.86.31 46.19.86.32 46.19.86.33 46.19.86.34 46.19.86.35 46.19.86.36 46.19.86.37 46.19.86.38 46.19.86.39 46.19.86.40 46.19.86.41 46.19.86.42 46.19.86.43',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  29 => 
  array (
    'id' => '39',
    'username' => NULL,
    'ip' => '46.19.86.62 46.19.86.63 46.19.86.64 46.19.86.65 46.19.86.66 46.19.86.67 46.19.86.68 46.19.86.69 46.19.86.70 46.19.86.71 46.19.86.72 46.19.86.73 46.19.86.74 46.19.86.75 46.19.86.76 46.19.86.77 46.19.86.78 46.19.86.79',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  30 => 
  array (
    'id' => '40',
    'username' => NULL,
    'ip' => '46.19.86.80 46.19.86.81 46.19.86.82 46.19.86.83 46.19.86.84 46.19.86.85 46.19.86.86 46.19.86.87 46.19.86.88 46.19.86.89 46.19.86.90 46.19.86.91 46.19.86.92 46.19.86.93 46.19.86.94 46.19.86.95 46.19.86.96 46.19.86.97',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  31 => 
  array (
    'id' => '41',
    'username' => NULL,
    'ip' => '46.19.86.98 46.19.86.99 46.19.86.100 46.19.86.101 46.19.86.102 46.19.86.103 46.19.86.104 46.19.86.105 46.19.86.106 46.19.86.107 46.19.86.108 46.19.86.109 46.19.86.110 46.19.86.111 46.19.86.112 46.19.86.113',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  32 => 
  array (
    'id' => '42',
    'username' => NULL,
    'ip' => '46.19.86.114 46.19.86.115 46.19.86.116 46.19.86.117 46.19.86.118 46.19.86.119 46.19.86.120 46.19.86.121 46.19.86.122 46.19.86.123 46.19.86.124 46.19.86.125 46.19.86.126 46.19.86.127 46.19.86.128',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  33 => 
  array (
    'id' => '43',
    'username' => NULL,
    'ip' => '46.19.86.129 46.19.86.130 46.19.86.131 46.19.86.132 46.19.86.133 46.19.86.134 46.19.86.135 46.19.86.136 46.19.86.137 46.19.86.138 46.19.86.139 46.19.86.140 46.19.86.141 46.19.86.142 46.19.86.143',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  34 => 
  array (
    'id' => '44',
    'username' => NULL,
    'ip' => '46.19.86.144 46.19.86.145 46.19.86.146 46.19.86.147 46.19.86.148 46.19.86.149 46.19.86.150 46.19.86.151 46.19.86.152 46.19.86.153 46.19.86.154 46.19.86.155 46.19.86.156 46.19.86.157 46.19.86.158',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  35 => 
  array (
    'id' => '45',
    'username' => NULL,
    'ip' => '46.19.86.159 46.19.86.160 46.19.86.161 46.19.86.162 46.19.86.163 46.19.86.164 46.19.86.165 46.19.86.166 46.19.86.167 46.19.86.168 46.19.86.169 46.19.86.170 46.19.86.171 46.19.86.172 46.19.86.173',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  36 => 
  array (
    'id' => '46',
    'username' => NULL,
    'ip' => '46.19.86.174 46.19.86.175 46.19.86.176 46.19.86.177 46.19.86.178 46.19.86.179 46.19.86.180 46.19.86.181 46.19.86.182 46.19.86.183 46.19.86.184 46.19.86.185 46.19.86.186 46.19.86.187 46.19.86.188',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  37 => 
  array (
    'id' => '47',
    'username' => NULL,
    'ip' => '46.19.86.189 46.19.86.190 46.19.86.191 46.19.86.192 46.19.86.193 46.19.86.194 46.19.86.195 46.19.86.196 46.19.86.197 46.19.86.198 46.19.86.199 46.19.86.200 46.19.86.201 46.19.86.202 46.19.86.203',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  38 => 
  array (
    'id' => '48',
    'username' => NULL,
    'ip' => '46.19.86.204 46.19.86.205 46.19.86.206 46.19.86.207 46.19.86.208 46.19.86.209 46.19.86.210 46.19.86.211 46.19.86.212 46.19.86.213 46.19.86.214 46.19.86.215 46.19.86.216 46.19.86.217 46.19.86.218',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  39 => 
  array (
    'id' => '49',
    'username' => NULL,
    'ip' => '46.19.86.219 46.19.86.220 46.19.86.221 46.19.86.222 46.19.86.223 46.19.86.224 46.19.86.225 46.19.86.226 46.19.86.227 46.19.86.228 46.19.86.229 46.19.86.230 46.19.86.231 46.19.86.232 46.19.86.233',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  40 => 
  array (
    'id' => '50',
    'username' => NULL,
    'ip' => '46.19.86.239 46.19.86.240 46.19.86.241 46.19.86.242 46.19.86.243 46.19.86.244 46.19.86.245 46.19.86.246 46.19.86.247 46.19.86.248 46.19.86.249 46.19.86.250 46.19.86.251 46.19.86.252 46.19.86.253',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  41 => 
  array (
    'id' => '51',
    'username' => NULL,
    'ip' => '46.19.86.254 46.19.86.255',
    'email' => NULL,
    'message' => 'Automated game play is not welcome on this server.',
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
  42 => 
  array (
    'id' => '52',
    'username' => NULL,
    'ip' => '24.186.201.163',
    'email' => NULL,
    'message' => NULL,
    'expire' => NULL,
    'ban_creator' => '1788',
  ),
);

?>