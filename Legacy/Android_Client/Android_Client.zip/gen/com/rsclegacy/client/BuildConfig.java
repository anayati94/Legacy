/** Automatically generated file. DO NOT MODIFY */
package com.rsclegacy.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}